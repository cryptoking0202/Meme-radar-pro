# Meme Radar Pro — starter v0.1

This is an iPhone-friendly, read-only cloud dashboard starter. It is **not** a finished all-chain launch/insider tracker.

## Included
- Responsive Safari dashboard
- Public DEX Screener latest token-profile and boost feeds
- Token pair lookup API route
- GoPlus EVM token-security route
- Local public-wallet watchlist UI
- Seven chain labels: Solana, Ethereum, Base, BNB Chain, Polygon, Arbitrum, Avalanche

## Important limitations
- DEX Screener latest profiles/boosts are not a complete new-pair firehose. This feed does not guarantee every token launch or one-minute detection.
- Wallet watchlist is currently local-only. Live big-wallet alerts and clustering need chain-specific RPC/indexer subscriptions and a backend database.
- “Insider” is only a heuristic based on public on-chain links; it cannot prove identity or wrongdoing.
- Social/news feeds require separate authorized API access.
- Trading is disabled. No wallet signing, private-key handling, swaps or auto-execution are implemented.

## Run locally
Requires Node.js 18+.
1. Copy `.env.example` to `.env`.
2. Run `npm install`
3. Run `npm start`
4. Open `http://localhost:3000`

## Cloud deployment
Deploy as a Node web service on Railway/Render/Fly.io or similar. Set the start command to `npm start`, and add environment variables from `.env.example`. Use HTTPS. Do not expose RPC/API secrets in frontend code.

## Next production integrations
1. Solana: launch/pool event subscriptions via a dedicated provider (e.g. Helius) and durable event ingestion.
2. EVM chains: WebSocket logs/new-pair factory events via an RPC/indexer provider.
3. Wallet intelligence: curated public wallet watchlists, transfer graph, first-funder links, early buyer cohorts and alert thresholds.
4. Security: GoPlus supported-chain checks plus Solana-specific security checks.
5. Social/news: X API and authorized feeds; Telegram Bot API for notifications if enabled.
6. Database/queue: Postgres + Redis or equivalent; deduplicate token and transaction events.
7. Trading: paper-trading simulation first. Live execution only through a separately funded burner wallet, transaction simulation, spend caps and manual confirmation. Never store a seed phrase in the dashboard.

## Sources
- DEX Screener API: https://docs.dexscreener.com/api/reference
- GoPlus API: https://docs.gopluslabs.io/reference/api-overview
- Alchemy docs: https://www.alchemy.com/docs
- X API: https://help.x.com/en/rules-and-policies/x-api
- Telegram Bot API: https://core.telegram.org/bots/api

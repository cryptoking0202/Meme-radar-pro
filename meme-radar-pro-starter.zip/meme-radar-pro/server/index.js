import express from "express";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static("public"));

const DEX = "https://api.dexscreener.com";
const chains = ["solana","ethereum","base","bsc","polygon","arbitrum","avalanche"];

async function getJson(url) {
  const r = await fetch(url, { headers: { "accept": "application/json" } });
  if (!r.ok) throw new Error(`Upstream API returned ${r.status}`);
  return r.json();
}

app.get("/api/health", (_req, res) => res.json({
  status: "ok",
  mode: "read-only starter",
  chains,
  note: "Live launch indexing and wallet surveillance require RPC/indexer credentials."
}));

app.get("/api/discovery", async (_req, res) => {
  try {
    const [profiles, boosts, topBoosts] = await Promise.all([
      getJson(`${DEX}/token-profiles/latest/v1`),
      getJson(`${DEX}/token-boosts/latest/v1`),
      getJson(`${DEX}/token-boosts/top/v1`)
    ]);
    const unique = new Map();
    for (const item of [...(Array.isArray(profiles)?profiles:[]), ...(Array.isArray(boosts)?boosts:[]), ...(Array.isArray(topBoosts)?topBoosts:[])]) {
      const key = `${item.chainId}:${item.tokenAddress}`;
      if (item.chainId && item.tokenAddress && chains.includes(item.chainId)) {
        unique.set(key, {...(unique.get(key)||{}), ...item});
      }
    }
    res.json({ items: [...unique.values()], source: "DEX Screener public endpoints", fetchedAt: new Date().toISOString() });
  } catch (e) {
    res.status(502).json({ error: e.message, items: [] });
  }
});

app.get("/api/token/:chain/:address", async (req, res) => {
  const { chain, address } = req.params;
  if (!chains.includes(chain)) return res.status(400).json({error:"Chain not enabled in this starter."});
  try {
    const pairs = await getJson(`${DEX}/token-pairs/v1/${encodeURIComponent(chain)}/${encodeURIComponent(address)}`);
    res.json({ pairs, fetchedAt: new Date().toISOString() });
  } catch (e) { res.status(502).json({error:e.message}); }
});

// GoPlus EVM security check. Solana security requires its dedicated Solana endpoint/auth flow.
const goplusIds = {ethereum:"1", bsc:"56", polygon:"137", avalanche:"43114", arbitrum:"42161", base:"8453"};
app.get("/api/security/:chain/:address", async (req, res) => {
  const id = goplusIds[req.params.chain];
  if (!id) return res.status(400).json({error:"Use an EVM chain supported by this starter security route."});
  try {
    const data = await getJson(`https://api.gopluslabs.io/api/v1/token_security/${id}?contract_addresses=${encodeURIComponent(req.params.address.toLowerCase())}`);
    res.json(data);
  } catch (e) { res.status(502).json({error:e.message}); }
});

app.get("*", (_req,res) => res.sendFile(process.cwd()+"/public/index.html"));
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Meme Radar Pro listening on ${port}`));
